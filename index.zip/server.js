// Servidor Express com painel administrativo aprimorado
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const db = require('./db');
const app = express();

// Configurações
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));

// Rota de envio do formulário
app.post('/enviar', (req, res) => {
  const identificado = req.body.identificado === 'sim';
  const nome = identificado ? req.body.nome || null : null;
  const telefone = identificado ? req.body.telefone || null : null;
  const email = identificado ? req.body.email || null : null;
  const tipo = req.body.tipo;
  const descricao = req.body.descricao;

  const sql = 'INSERT INTO denuncias (identificado, nome, telefone, email, tipo, descricao) VALUES (?, ?, ?, ?, ?, ?)';
  const values = [identificado, nome, telefone, email, tipo, descricao];

  db.query(sql, values, (err) => {
    if (err) {
      console.error('Erro ao inserir denúncia:', err);
      return res.status(500).send('Erro ao enviar denúncia');
    }
    res.redirect('/sucesso');
  });
});

// Página de sucesso
app.get('/sucesso', (req, res) => {
  res.send('<h2>Denúncia enviada com sucesso!</h2><p><a href="/">Voltar</a></p>');
});

// Painel administrativo
app.get('/admin', (req, res) => {
  db.query('SELECT * FROM denuncias ORDER BY data_envio DESC', (err, results) => {
    if (err) {
      console.error('Erro ao buscar denúncias:', err);
      return res.status(500).send('Erro ao carregar denúncias');
    }
    res.render('admin', { denuncias: results });
  });
});

// Inicialização do servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
